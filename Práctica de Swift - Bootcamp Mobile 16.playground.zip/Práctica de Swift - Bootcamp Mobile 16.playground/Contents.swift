import Foundation


//1

struct Client: Hashable{
    
    let name: String
    let age: Int
    let height: Double
    
    init(_ name: String,_ age: Int,_ height: Double){
        self.name = name
        self.age = age
        self.height = height
    }
    
}

struct Reservation: Hashable{
    
    let id:Int
    let hotelName:String
    let clientsList: Set<Client>
    let duration: Int
    let price: Double
    let breakfast: Bool
    
    init(_ id: Int,_ hotelName: String,_ clientsList: Set<Client>,_ duration: Int,_ price: Double,_ breakfast: Bool){
        self.id = id
        self.hotelName = hotelName
        self.clientsList = clientsList
        self.duration = duration
        self.price = price
        self.breakfast = breakfast
    }
}

enum ReservationError: Error{
    case reservationWithSameId
    case customerAlreadyHasAReservation
    case ClientReservationNotFound
}

//2

class HotelReservationManager{
    
    //variable que se usara como counter
    private var counter: Int
    
    //variables
    private var reservationList: Set<Reservation>
    
    //constructor
    init(){
        self.reservationList = []
        self.counter = 0
        
    }
    
    //método para añadir una reservation
    func addReservation(_ clientsList: Set<Client>,_ duration: Int,_ breakfast: Bool) throws -> Reservation{
        
        //constante nombre del hotel
        let hotelName: String = "Luchadores"

        //variable reservation y calculo de price
        var reservation: Reservation
        counter+=1
        if(breakfast){
            reservation = Reservation(counter, hotelName, clientsList, duration, (Double(clientsList.count)*20*Double(duration)*1.25), breakfast)
        }else{
            reservation = Reservation(counter, hotelName, clientsList, duration, (Double(clientsList.count)*20*Double(duration)*1), breakfast)
        }
        
        //añadimos la reservation al listado de reservas directamente si es la primera reserva que se agrega
        if(reservationList == []){
            self.reservationList.insert(reservation)
        }else{
            //se verifica que no se repita el ID y nombre de cliente de la reservación que se va a agregar con las reservaciones que ya tenga la reservationList antes de agregarla
            try reservationList.forEach {res in
                        if(res.id == reservation.id){
                            throw ReservationError.reservationWithSameId
                        }else{
                            try reservation.clientsList.forEach{ cli in
                                try clientsList.forEach{ clie in
                                    if(clie.name == cli.name){
                                        throw ReservationError.customerAlreadyHasAReservation
                                    }
                                }
                            }
                        }
            }

        }
                
        //añadimos la reservation al listado de reservas
        self.reservationList.insert(reservation)
        
        //retornamos la reservation
        return reservation
    }
    
    //método para cancelar una reservation
    func cancelReservation (_ id: Int) throws {
        //lanzar reservationError si no existe la reservation
        var canceled: Bool = false
        getReservationList().forEach{ res in
            if(res.id == id){
                reservationList.remove(res)
                canceled = true
            }
        }
        if (canceled == false){
            throw ReservationError.ClientReservationNotFound
        }
    }
    
    //método para obtener la lista de reservas actuales
    func getReservationList() -> Set<Reservation>{
        return self.reservationList
    }
}
