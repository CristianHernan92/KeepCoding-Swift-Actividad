import Foundation


//1

struct Client: Hashable{
    
    let name: String
    let age: Int
    let height: Double
    
    init(_ name: String,_ age: Int,_ height: Double){
        self.name = name
        self.age = age
        self.height = height
    }
    
}

struct Reservation: Hashable{
    
    let id:Int
    let hotelName:String
    let clientsList: Set<Client>
    let duration: Int
    let price: Double
    let breakfast: Bool
    
    init(_ id: Int,_ hotelName: String,_ clientsList: Set<Client>,_ duration: Int,_ price: Double,_ breakfast: Bool){
        self.id = id
        self.hotelName = hotelName
        self.clientsList = clientsList
        self.duration = duration
        self.price = price
        self.breakfast = breakfast
    }
}

enum ReservationError: Error{
    case reservationWithSameId
    case customerAlreadyHasAReservation
    case clientReservationNotFound
    //otros case creados por mi
    case reservationNotAddedCorrectly
    case reservationNotDeletedCorrectly
    case reservationPricesDoNotMatch
}

//error para la función "createThreeClientsList()" por si se repinten los nombres de una lista de cliente
enum ClientsListError: Error{
    case repeatedCustomerName
}

//2

class HotelReservationManager{
    
    //variable que se usara como counter
    private var counter: Int
    
    //variables
    private var reservationList: Set<Reservation>
    
    //constructor
    init(){
        self.reservationList = []
        self.counter = 0
        
    }
    
    //método para añadir una reservation
    func addReservation(_ clientsList: Set<Client>,_ duration: Int,_ breakfast: Bool) throws -> Reservation{
        
        //constante nombre del hotel
        let hotelName: String = "Luchadores"

        //variable reservation y calculo de price
        var reservation: Reservation
        counter+=1
        if(breakfast){
            reservation = Reservation(counter, hotelName, clientsList, duration, (Double(clientsList.count)*20*Double(duration)*1.25), breakfast)
        }else{
            reservation = Reservation(counter, hotelName, clientsList, duration, (Double(clientsList.count)*20*Double(duration)*1), breakfast)
        }
        
        //añadimos la reservation al listado de reservas directamente si es la primera reserva que se agrega
        if(reservationList == []){
            self.reservationList.insert(reservation)
        }else{
            //se verifica que no se repita el ID y nombre de cliente de la reservación que se va a agregar con las reservaciones que ya tenga la reservationList antes de agregarla
            try reservationList.forEach {res in
                        if(res.id == reservation.id){
                            throw ReservationError.reservationWithSameId
                        }else{
                            try reservation.clientsList.forEach{ cli in
                                try res.clientsList.forEach{ clie in
                                    if(clie.name == cli.name){
                                        throw ReservationError.customerAlreadyHasAReservation
                                    }
                                }
                            }
                        }
            }

        }
                
        //añadimos la reservation al listado de reservas
        self.reservationList.insert(reservation)
        
        //retornamos la reservation
        return reservation
    }
    
    //método para cancelar una reservation
    func cancelReservation (_ id: Int) throws {
        //lanzar reservationError si no existe la reservation
        var canceled: Bool = false
        getReservationList().forEach{ res in
            if(res.id == id){
                reservationList.remove(res)
                canceled = true
            }
        }
        if (canceled == false){
            throw ReservationError.clientReservationNotFound
        }
    }
    
    //método para obtener la lista de reservas actuales
    func getReservationList() -> Set<Reservation>{
        return self.reservationList
    }
}

//TEST


//variable de clase HotelReservationManager
var hrm: HotelReservationManager = HotelReservationManager()

func testAddReservation(){
    //arreglo de tres listas de clientes
    var clientsListArray: [Set<Client>]
    //reservations retornadas de la función addReservation
    var reservations: [Reservation] = []
    do{
        try clientsListArray = createThreeClientsList()
        for clientsList in clientsListArray{
            try reservations.append(hrm.addReservation(clientsList, 2, true))
        }
        //vderificamos que las reservaciones que se fueron agregando a la lista de reservaciones se hayan añadido correctamente
        for reservation in reservations{
            if(hrm.getReservationList().contains(reservation) == false){
                throw ReservationError.reservationNotAddedCorrectly
            }
        }
    }catch ReservationError.customerAlreadyHasAReservation{
        print ("Customer already has a reservation")
    }catch ReservationError.reservationWithSameId{
        print("Reservation with same id")
    }catch ClientsListError.repeatedCustomerName{
        print("Se repitieron dos nombres en alguna lista de clientes")
    }catch ReservationError.reservationNotAddedCorrectly{
        print("Alguna reservación no se agregó correctamente")
    }catch{
        print("Error")
    }
}

func testCancelReservation(){
    let id: Int = 1
    do{
        try hrm.cancelReservation(id)
        //se verifica que se haya borrado correctamente el ID
        try hrm.getReservationList().forEach{ reservation in
            if(reservation.id == id){
                throw ReservationError.reservationNotDeletedCorrectly
            }
        }
        //assert(hrm.getReservationList()., "No se agrego correctamente alguna reservación")
    }catch ReservationError.clientReservationNotFound{
        print("No se encontró una reservación con dicho ID")
    }catch ReservationError.reservationNotDeletedCorrectly{
        print("No se borro correctamente la reservación con el ID")
    }catch{
        print("Error")
    }
}

func testReservationPrice(){
    
    var clientList: Set<Client> = []
    var client: Client = Client("Fransua", 31, 1.80)
    clientList.insert(client)
    
    var clientListTwo: Set<Client> = []
    var clientTwo: Client = Client("Paulo", 20, 1.80)
    clientListTwo.insert(clientTwo)
    
    var reservationOne: Reservation
    var reservationTwo: Reservation
    
    do{
        try reservationOne = hrm.addReservation(clientList, 2, true)
        try reservationTwo = hrm.addReservation(clientListTwo, 2, true)
        if(reservationOne.price != reservationTwo.price){
            throw ReservationError.reservationPricesDoNotMatch
        }
    }
    catch ReservationError.reservationPricesDoNotMatch{
        print("Precios de dos reservasiones deberían coincidir y no coinciden")
    }
    catch{
        print(error)
    }
    
}

// // //

//
private func createThreeClientsList() throws -> [Set<Client>]{
    
    var clientsListOne: Set<Client> = []
    
    clientsListOne.insert(Client("Cristian", 31, 1.80))
    clientsListOne.insert(Client("Franco", 18, 1.70))
    clientsListOne.insert(Client("Juana", 21, 1.80))
    clientsListOne.insert(Client("Lucas", 25, 1.67))
    clientsListOne.insert(Client("Gabriela", 35, 1.90))
    
    //se verifica que no se repitan los nombres ingresados para en la lista de clientes
    var array: [String] = []
    try clientsListOne.forEach{ cliente in
        if(array.contains(cliente.name)){
            throw ClientsListError.repeatedCustomerName
        }
        array.append(cliente.name)
    }
    
    var clientsListTwo: Set<Client> = []
    
    clientsListTwo.insert(Client("Cristina", 31, 1.80))
    clientsListTwo.insert(Client("Catriel", 18, 1.70))
    clientsListTwo.insert(Client("Esteban", 21, 1.80))
    clientsListTwo.insert(Client("Lautaro", 25, 1.67))
    clientsListTwo.insert(Client("Francisco", 35, 1.90))
    
    //se verifica que no se repitan los nombres ingresados para en la lista de clientes
    array.removeAll()
    try clientsListTwo.forEach{ cliente in
        if(array.contains(cliente.name)){
            throw ClientsListError.repeatedCustomerName
        }
        array.append(cliente.name)
    }
    
    var clientsListThree: Set<Client> = []
    
    clientsListThree.insert(Client("Viviana", 31, 1.80))
    clientsListThree.insert(Client("Alcides", 18, 1.70))
    clientsListThree.insert(Client("Hernán", 21, 1.80))
    clientsListThree.insert(Client("Ezequiel", 25, 1.67))
    clientsListThree.insert(Client("Erika", 35, 1.90))
    
    //se verifica que no se repitan los nombres ingresados para en la lista de clientes
    array.removeAll()
    try clientsListThree.forEach{ cliente in
        if(array.contains(cliente.name)){
            throw ClientsListError.repeatedCustomerName
        }
        array.append(cliente.name)
    }
    
    return [clientsListOne,clientsListTwo,clientsListThree]
}
// // //

//

testAddReservation()
testCancelReservation()
testReservationPrice()
